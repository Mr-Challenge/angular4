import { TranslateService } from '@ngx-translate/core';
import { ITdDataTableColumn } from '@covalent/core';
import { Injectable } from '@angular/core'
import { HttpClient } from '../../shared/security/httpClient.service';
import { BusinessOperations } from '../../BusinessOperations';

@Injectable()
export class GeneralDataGridService {

    constructor(private BO: BusinessOperations,
                private http: HttpClient) {
    }

    getData(size: number, page: number, searchTerms, sort: any[]) {
      let pageData = {
        pagination: {
          size: size,
          page: page,
          total: 1
        },
        employeeId: searchTerms.employeeId,
        age: searchTerms.age,
        firstName: searchTerms.firstName,
        lastName: searchTerms.lastName,
        sort: sort
      }
      return this.http.post(this.BO.postEmployeeSearch(), pageData)
                      .map(res => res.json());
    }

    saveData(data) {
      let obj = {
        id: data.id,
        employeeId: data.employeeId,
        age: data.age,
        firstName: data.firstName,
        lastName: data.lastName
      };

      return this.http.post(this.BO.postEmployee(),  obj ).map(res => res.json());
    }

    deleteData(id) {
      return this.http.delete(this.BO.deleteEmployee() + id)
    }

    searchData(criteria) {
      return this.http.post(this.BO.postEmployeeSearch(), { criteria: criteria }).map(res => res.json());
    }

}

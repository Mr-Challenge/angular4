import { Router } from '@angular/router';
import { AuthService } from '../shared/security/auth.service';
import { TranslateService } from '@ngx-translate/core';
import { GeneralAddDialogComponent } from './generaladdDialog/generaladdDialog.component';
import { MdDialog, MdDialogRef } from '@angular/material';
import { Component, OnInit, ViewChild } from '@angular/core';
import { IPageChangeEvent, ITdDataTableColumn, ITdDataTableSortChangeEvent, TdDataTableColumnComponent, TdDataTableComponent, TdDialogService } from '@covalent/core';
import { GeneralDataGridService } from './shared/generaldataGrid.service';
import * as _ from 'lodash';


@Component({
    selector: 'app-sampledata-grid',
    templateUrl: './generaldataGrid.component.html'
}) export class GeneralDataGridComponent implements OnInit {

    selectedRow: any;
    dialogRef: MdDialogRef < GeneralAddDialogComponent > ;
    dataTotal: number;
    searchBox = false;
    currentPage = 1;
    pageSize = 5;
    sorting: any[] = [];
    searchTerms: any = {
        name: null,
        surname: null,
        age: null,
        employeeid: null
    };

    data:any = {
      name: Mahesh,
      surname: Patkar,
      age: 25,
      employeeid: 1
    };
    constructor(public dialog: MdDialog, public authService: AuthService, public router: Router, private dataGridService: GeneralDataGridService, private _dialogService: TdDialogService, private translate: TranslateService) {}
    ngOnInit(): void {
        this.getData();
    }
    getTranslation(text: string): string {
        let value: string;
        let me = this;
        this.translate.get(text).subscribe((res) => {
            value = res;
        });
        this.translate.onLangChange.subscribe(() => {
            me.columns.forEach(column => {
                this.translate.get('generaldatagrid.columns.' + column.name).subscribe((res) => {
                    column.label = res;
                });
            });
            me.dataTable.refresh();
        });
        return value;
    }
    getData(): void {
        let me = this;
        this.dataGridService.getData(this.pageSize, this.currentPage, this.searchTerms, this.sorting).subscribe((res) => {
            me.data = res.result;
            me.dataTotal = res.pagination.total;
        }, (error) => {
            this._dialogService.openConfirm({
                message: JSON.parse(error.text()).message,
                title: this.getTranslation('generaldatagrid.alert.title')
            }).afterClosed().subscribe((accept: boolean) => {
                if (accept) {
                    this.authService.setLogged(false);
                    this.router.navigate(['/login']);
                }
            });
        });
    }
    sort(sortEvent: ITdDataTableSortChangeEvent): void {
        this.sorting = _.reject(this.sorting, {
            'name': sortEvent.name
        });
        this.sorting.push({
            'name': sortEvent.name,
            'direction': sortEvent.order
        });
        this.getData();
    }
    search(searchForm): void {
        _.forIn(searchForm.value, function(value, key) {
            if (value === '') {
                searchForm.value[key] = null;
            }
        });
        this.searchTerms = searchForm.value;
        this.getData();
    }
    searchReset(form): void {
        form.reset();
        this.search(form);
    }
    openSearchBox() {
        this.searchBox = !this.searchBox;
    }
    page(pagingEvent: IPageChangeEvent): void {
        this.pageSize = pagingEvent.pageSize;
        this.currentPage = pagingEvent.page;
        this.getData();
    }
    selectEvent(e): void {
        e.selected ? this.selectedRow = e.row : this.selectedRow = undefined;
    }
    openDialog(): void {
        this.dialogRef = this.dialog.open(GeneralAddDialogComponent);
        this.dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.dataGridService.saveData(result).subscribe(() => {
                    this.getData();
                }, (error) => {
                    this._dialogService.openAlert({
                        message: JSON.parse(error.text()).message,
                        title: this.getTranslation('generaldatagrid.alert.title')
                    }).afterClosed().subscribe((accept: boolean) => {
                        if (accept) {
                            this.authService.setLogged(false);
                            this.router.navigate(['/login']);
                        }
                    });
                });
            }
        });
    }
    openEditDialog(): void {
        this.dialogRef = this.dialog.open(GeneralAddDialogComponent, {
            data: this.selectedRow,
        });
        this.dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.dataGridService.saveData(result).subscribe(() => {
                    this.getData();
                }, (error) => {
                    this._dialogService.openAlert({
                        message: JSON.parse(error.text()).message,
                        title: this.getTranslation('generaldatagrid.alert.title')
                    }).afterClosed().subscribe((accept: boolean) => {
                        if (accept) {
                            this.authService.setLogged(false);
                            this.router.navigate(['/login']);
                        }
                    });
                });
            }
        });
    }
    openConfirm(): void {
        this._dialogService.openConfirm({
            message: this.getTranslation('generaldatagrid.alert.message'),
            title: this.getTranslation('generaldatagrid.alert.title'),
            cancelButton: this.getTranslation('generaldatagrid.alert.cancelBtn'),
            acceptButton: this.getTranslation('generaldatagrid.alert.acceptBtn'),
        }).afterClosed().subscribe((accept: boolean) => {
            if (accept) {
                this.dataGridService.deleteData(this.selectedRow.id).subscribe(() => {
                    this.getData();
                }, (error) => {
                    this._dialogService.openAlert({
                        message: JSON.parse(error.text()).message,
                        title: this.getTranslation('generaldatagrid.alert.title')
                    }).afterClosed().subscribe((acceptance: boolean) => {
                        if (acceptance) {
                            this.authService.setLogged(false);
                            this.router.navigate(['/login']);
                        }
                    });
                });
            }
        });
    }
}

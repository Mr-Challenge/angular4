import { Component } from '@angular/core';

@Component({
  selector: 'app-initial-page',
  templateUrl: './initial-page.component.html'
})
export class InitialPageComponent {

}

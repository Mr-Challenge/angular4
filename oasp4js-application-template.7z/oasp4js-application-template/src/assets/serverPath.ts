

export let url = 'http://localhost:8081/HelloWorldDevon1-server/services/rest/';
export let logoColor = `

`
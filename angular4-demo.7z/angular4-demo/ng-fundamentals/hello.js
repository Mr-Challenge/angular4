//To Print in console screen
console.log('Welcome to angular');

//Declaring variables
var numberVar = 6; //number,string,boolean, undefined, null
console.log(typeof(numberVar));//To get the type for primitives

//Create an instance 
var dt = new Date();
console.log(dt.constructor.name); //To get the type other than primitives

//To Create object
var obj  = {};
obj.name = 'Karthik';
console.log(obj['name']);

//To Create Array
var arr = [65,87,43,98];
console.log(arr);


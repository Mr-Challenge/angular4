import { Component } from '@angular/core';

@Component({
    selector:'app-root',
    templateUrl:'./app.component.html'
})
export class AppComponent{
    showStatus:boolean;
    firstName:string;
    lastName:string;

    constructor(){
        this.showStatus = true;
        this.firstName = 'Karthik';
        this.lastName = 'Muthukrishnan';
    }
}
import { Component, OnInit, OnDestroy, OnChanges, DoCheck, SimpleChanges } from '@angular/core';

@Component({
    selector: 'sample-app',
    template: `<div class="well">
        <h2>Sample Component</h2>
        <span>First Name</span>
        <input type="text" class="form-control" [value]="firstName" readonly>
        <span>Last Name</span>
        <input type="text" class="form-control" [value]="lastName" readonly>
    </div>`,
    inputs:['firstName','lastName']
})
export class SampleComponent implements OnInit, OnDestroy, OnChanges, DoCheck {
    firstName:string;
    lastName:string;

    constructor() {
        console.log('Sample Component Constructor invoked');
    }
    ngOnInit(): void{
        //Component Initialization Code
        console.log('Sample Component OnInit Invoked');
    }

    ngOnChanges(changes: SimpleChanges): void{
        //When the any property value changes in that component
        console.log('Sample Component OnChanges Invoked');
        console.log(changes);
    }
    ngOnDestroy(): void{
        //Component Removed from the DOM - Cleanup the resources
        console.log('Sample Component OnnDestroy Invoked');
    }

    ngDoCheck(): void{
        //Custom check can be done when any property changes
        console.log('Sample Component DoCheck Invoked');
    }
}
//AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked
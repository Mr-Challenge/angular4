import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
    selector: 'inner-app',
    template: `<div class="well">
        <h2>Inner Component</h2>
    </div>`
})
export class InnerComponent implements OnInit, OnDestroy {
    constructor() {
        console.log('Inner Component Constructor invoked');
    }
    ngOnInit(): void{
        //Component Initialization Code - XHR Initialization
        console.log('Inner Component OnInit Invoked');
    }
    ngOnDestroy(): void{
        //Component Removed from the DOM - Cleanup the resources
        console.log('Inner Component OnnDestroy Invoked');
    }
}
export const URLS = {
    'todoGETURL':'http://jsonplaceholder.typicode.com/todos',
    'todoFakeGETURL':'http://localhost:3000/api/todos.json' //add api folder to assets section of angular-cli.json
}
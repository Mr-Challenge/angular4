import { Injectable } from '@angular/core';
import { Http } from '@angular/http';//deprecated
import { HttpClient, HttpHeaders } from '@angular/common/http';//stable
import { URLS } from '../constants/url.constants';
import { Todo } from '../models/todo';

import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class TodoService {
    constructor(public http: HttpClient) {

    }

    getAllTodos(): Observable<Todo[]> {
        return this.http.get<Todo[]>(URLS.todoGETURL);
    }

    getTodoById(id: number): Observable<Todo> {
        return this.http.get<Todo>(`${URLS.todoGETURL}/${id}`);
    }

    addTodo(todo: Todo):Observable<Todo> {
        return this.http.post<Todo>(URLS.todoGETURL, JSON.stringify(todo), {
            headers: new HttpHeaders({ 'Content-Type': 'application/json' })
        });
    }
}
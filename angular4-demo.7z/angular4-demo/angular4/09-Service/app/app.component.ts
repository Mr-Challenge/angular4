import { Component, Inject, OnInit } from '@angular/core';
import { CalculatorService } from './services/calculator.service';
import { TodoService } from './services/todo.service';
import { Todo } from './models/todo';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html'
    //providers:[ CalculatorService ] //Registering the Service to AppComponent
})
export class AppComponent implements OnInit {
    //calcService:CalculatorService;
    todos: Todo[];

    todoObj:Todo
    constructor( @Inject(CalculatorService) public calcService: CalculatorService,
        @Inject('square') public sqrFn: Function,
        @Inject('mail') public email: string,
        @Inject(TodoService) public todoService: TodoService) { //DI
        //this.calcService = new CalculatorService();
        this.todos = [];
        
        this.todoService.getTodoById(2).subscribe((todo:Todo)=>{
            console.log(todo);
        });

        this.todoObj =  {
            "userId": 9999,
            "id": 9999,
            "title": "Capgemini Title",
            "completed": true
        };
       
        this.todoService.addTodo(this.todoObj).subscribe((todo:Todo)=>{
            //console.log(todo);
            this.todos.push(todo);
        });
    }

    ngOnInit(): void {
        //Component initialization done here
        //XHR initialization to the propertes of the component
        this.todoService.getAllTodos().subscribe((todoList: Todo[]) => {
            this.todos = todoList;
        });
    }


}
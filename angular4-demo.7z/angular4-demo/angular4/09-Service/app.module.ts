import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { CalculatorService } from './app/services/calculator.service';
import { TodoService } from './app/services/todo.service';
import { HttpModule } from '@angular/http'; //deprecated
import { HttpClientModule } from '@angular/common/http'; //stable


@NgModule({
    imports: [BrowserModule, HttpClientModule],
    declarations: [AppComponent],
    bootstrap: [AppComponent],
    //Entire Application can use this services
    providers: [
        //To register the class as a Service
        CalculatorService,
        TodoService,
        //To register only a method
        {
            provide: 'square',
            useFactory: () => (n: number) => n * n
        },
        //to register only the values
        {
            provide: 'mail',
            useValue: 'karthik.muthukrishnan@capgemini.com'
        }
    ]
})
export class AppModule { }
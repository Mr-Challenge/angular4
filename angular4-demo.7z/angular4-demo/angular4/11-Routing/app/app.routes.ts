import { Routes} from '@angular/router';
import { HomeComponent } from './home-component/home.component';
import { AboutComponent } from './about-component/about.component';
import { AboutGuardService } from './services/about.guard.service';
import { ContactComponent } from './contact/contact.component';
import { NotFoundComponent } from './notfound-component/notfound.component';
import { contactRoutes } from './contact/contact.routes';

export const appRoutes: Routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },//Default route
    { path: 'home', component: HomeComponent },
    { path: 'about/:id', component: AboutComponent, canActivate: [AboutGuardService] },//id is a path parameter
    { path: 'contact', component: ContactComponent, children:contactRoutes },
    { path: '**', component: NotFoundComponent }

]
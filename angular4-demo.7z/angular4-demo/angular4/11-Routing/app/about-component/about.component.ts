import { Component, Inject } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';

@Component({
    selector:'app-about',
    template:`<div class="well">
        <h1>About Component</h1>
        <hr>
        <span>Id : {{ id }}</span>
        <hr>
        <button class="btn btn-primary" (click)="navigate()">Home</button>
    </div>`
})
export class AboutComponent{
    id:number;
    constructor(@Inject(ActivatedRoute) public routeDetails:ActivatedRoute,
                @Inject(Router) public router:Router){
                    this.routeDetails.params.subscribe((param)=>{
                        this.id = parseInt(param['id']);
                    });
    }

    navigate():void{
        this.router.navigate(['./home']);
    }
}
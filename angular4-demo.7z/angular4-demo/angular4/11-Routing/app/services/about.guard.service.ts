import { Injectable, Inject} from '@angular/core';
import { CanActivate,ActivatedRouteSnapshot,RouterStateSnapshot,Router } from '@angular/router';

@Injectable()
export class AboutGuardService implements CanActivate{

    constructor(@Inject(Router) public router:Router){

    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        console.log(route.params.id);
        console.log(route.url[1].path);
        var data = route.url[1].path;
        var regex = /^\d+$/;

        if(parseInt(data)>0 && data.match(regex) && !isNaN(parseInt(data))){
            return true;
        }else{
            this.router.navigate(['./home']);
            return false;
        }
    }
}
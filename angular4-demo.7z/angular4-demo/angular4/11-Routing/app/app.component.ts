import { Component } from '@angular/core';

@Component({
    selector:'app-root',
    templateUrl:'./app.component.html',
    styles:['.sty{color:blue}']
})
export class AppComponent{
    id:number;

    constructor(){
        this.id = 100;
    }
}
import {NgModule} from '@angular/core';
import { RouterModule } from '@angular/router';
import { appRoutes } from '../app.routes';

@NgModule({
    imports:[RouterModule.forChild(appRoutes)],//Whatever the userdefine module imports we are supposed to export it.
    exports:[RouterModule]
    //bootstrap:[] //It will be available only in root Module
})
export class ContactRouteModule{

}
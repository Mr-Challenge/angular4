import { Routes} from '@angular/router';
import { PermanentComponent } from './permanent-component/permananent.component';
import { TemporaryComponent } from './temporary-component/temporary.component';

export const contactRoutes: Routes = [
    { path: '', redirectTo: 'permanent', pathMatch: 'full' },//Default route
    { path: 'permanent', component: PermanentComponent },
    { path: 'temporary', component: TemporaryComponent }
]
import { Component } from '@angular/core';

@Component({
    selector:'app-permanent',
    template:`<div class="well">
        <h1>Permanent Component</h1>
    </div>`
})
export class PermanentComponent{}
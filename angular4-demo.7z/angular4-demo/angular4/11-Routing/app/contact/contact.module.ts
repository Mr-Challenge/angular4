import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { PermanentComponent } from "./permanent-component/permananent.component";
import { TemporaryComponent } from "./temporary-component/temporary.component";

@NgModule({
    imports:[CommonModule],
    declarations:[PermanentComponent,TemporaryComponent],
    exports:[CommonModule]
})
export class ContactModule{

}
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './app/home-component/home.component';
import { AboutComponent } from './app/about-component/about.component';
import { NotFoundComponent } from './app/notfound-component/notfound.component';
import { AboutGuardService } from './app/services/about.guard.service';
import { ContactComponent } from './app/contact/contact.component';
import { AppRouteModule } from './app/app.route.module';
import { ContactModule } from './app/contact/contact.module';

@NgModule({
    imports: [BrowserModule, AppRouteModule, ContactModule],
    declarations: [AppComponent, HomeComponent, AboutComponent, NotFoundComponent, ContactComponent],
    bootstrap: [AppComponent],
    providers: [AboutGuardService]
})
export class AppModule { }
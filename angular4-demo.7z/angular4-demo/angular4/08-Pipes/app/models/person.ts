export interface Person{
    name:string;
    hobbies:string[]
}
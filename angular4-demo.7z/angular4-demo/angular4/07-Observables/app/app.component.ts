import { Component } from '@angular/core';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';
import { Subscriber } from 'rxjs/Subscriber';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html'
})
export class AppComponent {
    constructor(){
        this.observableDemo();
    }
    observableDemo():void{
        
        /*var observableObj:Observable<number> =  Observable.from([1,2,3,4,5]);

        observableObj.subscribe((n:number)=>{
            console.log(`Number : ${n}`);
        },(err)=>{
            console.log(`Error : ${err}`);
        },()=>{
            console.log('All data retrieved. Task Completed successfully');
        });*/

        /*var promiseObj = Promise.resolve(6);
        var observableObj:Observable<number> =  Observable.fromPromise(promiseObj);
        observableObj.subscribe((n:number)=>{
            console.log(`Number : ${n}`);
        },(err)=>{
            console.log(`Error : ${err}`);
        },()=>{
            console.log('All data retrieved. Task Completed successfully');
        });*/

        /*var observableObj:Observable<MouseEvent> = Observable.fromEvent(document,'mousemove');

        observableObj.subscribe((e:MouseEvent)=>{
            document.querySelector('#target').innerHTML = `<h1>X : ${e.x} Y : ${e.y} </h1>`;
        });*/


        /*var observableObj:Observable<number> =  Observable.interval(1000);
        observableObj.subscribe((n:number)=>{
            console.log(`Number : ${n}`);
        });*/


        /*var observableObj:Observable<number> =  Observable.from([1,2,3,4])
                                                .map(function(n:number){
                                                    return n * 10;
                                                });
        observableObj.subscribe((n:number)=>{
            console.log(`Number : ${n}`);
        })*/

        var observableObj:Observable<number> = Observable.create(function(observer:Subscriber<number>){
            try{
                observer.next(5);
                observer.next(10);
                throw 'Exception occured';
            }catch(err){
                observer.error(err);
            }
            observer.next(15);
            observer.complete();
        });

        observableObj.subscribe((n:number)=>{
            console.log(`Number : ${n}`);
        },(err)=>{
            console.log(`Error : ${err}`);
        },()=>{
            console.log('Task completed');
        })
    }
}
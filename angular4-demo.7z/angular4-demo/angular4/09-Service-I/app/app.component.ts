import { Component } from '@angular/core';
import { CalculatorService } from './services/calculator.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html'
    //providers:[ CalculatorService ] //Registering the Service to AppComponent
})
export class AppComponent {
    //calcService:CalculatorService;

    constructor(private calcService:CalculatorService){ //DI
        //this.calcService = new CalculatorService();
        console.log(this.calcService.add(6,7));
    }

    
}
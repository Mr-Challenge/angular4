import { Component } from '@angular/core';
import { Employee } from './models/employee';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html'
})
export class AppComponent {
    status:boolean;
    cities:string[];
    employees:Employee[];
    counter:number;
    isPrimary:boolean;
    fontWeight:string;
    fontSize:string;
    fontStyle:string;
    modelProperty:string;

    constructor(){
        this.status = true;
        this.cities = ['Bengaluru','Chennai','Mumbai','Pune'];
        this.employees = [
            { id:101, name:'Ashik' },
            { id:102, name:'Karthik' },
            { id:103, name:'John' }
        ];
        this.counter = 0;
        this.isPrimary = false;
        this.fontSize = '20pt';
        this.fontWeight = 'normal';
        this.fontStyle = 'normal';
        this.modelProperty = 'Initial Value';
    }

    changeSize(e):void{
        var element:HTMLInputElement = e.currentTarget as HTMLInputElement;
        var size = element.value+'pt';
        this.fontSize = size;
    }

    setStatus():void{
        this.status = !this.status;
    }

}
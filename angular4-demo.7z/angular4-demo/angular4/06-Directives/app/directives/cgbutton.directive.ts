import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
    selector:'[data-cg-button]'
})
export class CGButtonDirective{
    @HostBinding('title') //binds the directive property(titleProperty) with the host element(button's title) property
    titleProperty:string; 
    
    constructor(){
        this.titleProperty = 'CG Button Directive Title';
    }

    @HostListener('mouseenter',['$event'])//binds the directive method(mouseEnter) with the host element eventlistener(onmouseenter) Method
    mouseEnter(event):void{
        var element = event.currentTarget;
        var style = element.attributes.getNamedItem('data-style').value;
        element.classList.add(style);
    }
    
    @HostListener('mouseleave',['$event'])//binds the directive method(mouseLeave) with the host element eventlistener(onmouseleave) Method
    mouseLeave(event):void{
        var element = event.currentTarget;
        var style = element.attributes.getNamedItem('data-style').value;
        element.classList.remove(style);
    }
    
}
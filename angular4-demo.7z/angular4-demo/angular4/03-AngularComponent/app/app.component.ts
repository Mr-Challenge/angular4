import { Component , ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'app-root',
    //Inline template
    /*template: `<div>
        <h1>Welcome to Angular 5</h1>
    </div>`*/

    //Linked template
    templateUrl: './app.component.html',

    //Internal Style
    /*styles: [
        '.sty01{color:red}',
        '.sty02{text-transform:uppercase}'
    ],*/

    //Linked Style
    styleUrls:[
        './app.component.css'
    ],
    encapsulation : ViewEncapsulation.Emulated //Default
})
export class AppComponent { 
    title:string;

    constructor(){
        this.title = 'Angular Components';
    }

}
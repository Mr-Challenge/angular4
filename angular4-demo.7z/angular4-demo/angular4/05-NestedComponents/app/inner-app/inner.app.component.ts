import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Person } from '../models/person';

@Component({
    selector: 'app-inner',
    templateUrl: './inner.app.component.html'
})
export class InnerAppComponent {
    innerAppMsg: string;

    @Input() //now appMsgHolder becomes input property for InnerAppComponent, we can receive the data as input from its parent
    appMsgHolder: string;//By default it cannot receive the input from its parent, we need to decorate with input decorator to achieve this

    @Output() //we can emit the data as output to its parent
    innerEvent: EventEmitter<string>; //Event emits a string

    @Output()
    personEvent: EventEmitter<Person>;

    personObj: Person;

    constructor() {
        this.innerAppMsg = 'Message from InnerAppComponent';
        this.innerEvent = new EventEmitter<string>();
        this.personObj = { firstName: 'Karthik', lastName: 'Muthukrishnan' };
        this.personEvent = new EventEmitter<Person>();
    }

    sendMsg(): void {
        //Triggering my custom Event
        this.innerEvent.emit(this.innerAppMsg);
    }

    sendPersonDetails(): void {
        //Triggering my custom Event
        this.personEvent.emit(this.personObj);
    }

}
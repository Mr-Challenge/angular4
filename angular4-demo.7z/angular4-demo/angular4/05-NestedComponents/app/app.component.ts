import { Component } from '@angular/core';
import {Person} from './models/person';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html'
})
export class AppComponent {
    appMsg: string;
    innerAppMsgHolder: string;
    personObjHolder:Person;

    constructor() {
        this.appMsg = 'Message from AppComponent';
        this.innerAppMsgHolder = '...';
        this.personObjHolder = {firstName:'', lastName:''};
    }

    getMsg(msg: string): void {
        this.innerAppMsgHolder = msg;
    }

    getPersonDetails(person:Person):void{
        this.personObjHolder = person;
    }
}
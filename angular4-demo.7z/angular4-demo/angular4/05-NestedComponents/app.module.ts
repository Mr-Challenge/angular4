import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { InnerAppComponent } from './app/inner-app/inner.app.component';

@NgModule({
    imports: [BrowserModule],
    declarations: [AppComponent, InnerAppComponent],
    bootstrap: [AppComponent]
})
export class AppModule { }